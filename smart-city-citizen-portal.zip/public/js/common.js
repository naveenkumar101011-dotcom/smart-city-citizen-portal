// =====================================================================
// Smart City Portal - Common Utilities, API Fetcher, Modal & Toasts
// =====================================================================

const API_BASE = ''; // relative to domain

// Auth Token management
function getToken() {
  return localStorage.getItem('smart_city_token');
}

function setToken(token) {
  localStorage.setItem('smart_city_token', token);
}

function removeToken() {
  localStorage.removeItem('smart_city_token');
  localStorage.removeItem('smart_city_user');
}

function getUser() {
  const user = localStorage.getItem('smart_city_user');
  return user ? JSON.parse(user) : null;
}

function setUser(user) {
  localStorage.setItem('smart_city_user', JSON.stringify(user));
}

// API Request Wrapper
async function apiFetch(endpoint, options = {}) {
  const token = getToken();
  const headers = {
    ...options.headers
  };

  // If not FormData, set Content-Type JSON
  if (!(options.body instanceof FormData)) {
    headers['Content-Type'] = 'application/json';
  }

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  try {
    const response = await fetch(`${API_BASE}${endpoint}`, {
      ...options,
      headers
    });

    const data = await response.json();

    if (response.status === 401) {
      removeToken();
      if (!window.location.pathname.endsWith('index.html') && window.location.pathname !== '/') {
        window.location.href = '/';
      }
    }

    return data;
  } catch (error) {
    console.error('API Error:', error);
    return { success: false, message: 'Network or server communication error.' };
  }
}

// Toast Notifications
function showToast(message, type = 'info') {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  
  const icon = type === 'success' ? 'fa-circle-check' : (type === 'error' ? 'fa-triangle-exclamation' : 'fa-circle-info');
  toast.innerHTML = `
    <i class="fa-solid ${icon}"></i>
    <span>${message}</span>
  `;

  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(100%)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}

// Modal Handlers
function openModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
  }
}

function closeModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.remove('active');
    document.body.style.overflow = '';
  }
}

// Close modals when clicking overlay background
document.addEventListener('click', (e) => {
  if (e.target.classList.contains('modal-overlay')) {
    e.target.classList.remove('active');
    document.body.style.overflow = '';
  }
});

// Helper Formatters
function formatDate(dateStr) {
  if (!dateStr) return 'N/A';
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}

function formatCurrency(amount) {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 2
  }).format(amount);
}

// Dark / Light Theme Toggle
function toggleTheme() {
  const currentTheme = document.documentElement.getAttribute('data-theme');
  const targetTheme = currentTheme === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', targetTheme);
  localStorage.setItem('smart_city_theme', targetTheme);
}

// Init theme on load
(function initTheme() {
  const savedTheme = localStorage.getItem('smart_city_theme') || 'light';
  document.documentElement.setAttribute('data-theme', savedTheme);
})();
