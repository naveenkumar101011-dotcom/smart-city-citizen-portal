// =====================================================================
// Smart City Portal - Authentication & Session Handler
// =====================================================================

document.addEventListener('DOMContentLoaded', () => {
  initAuthUI();
});

function initAuthUI() {
  const user = getUser();
  const authNavContainer = document.getElementById('auth-nav-container');

  if (authNavContainer) {
    if (user) {
      // User is logged in
      const dashboardLink = user.role === 'citizen' ? '/citizen' : '/admin';
      const roleBadgeClass = user.role === 'citizen' ? 'badge-citizen' : (user.role === 'officer' ? 'badge-officer' : 'badge-admin');

      authNavContainer.innerHTML = `
        <div style="display: flex; align-items: center; gap: 0.75rem;">
          <a href="${dashboardLink}" class="btn btn-secondary btn-sm">
            <i class="fa-solid fa-gauge"></i> My Dashboard
          </a>
          <span class="user-role-badge ${roleBadgeClass}">${user.role}</span>
          <button onclick="handleLogout()" class="btn btn-outline btn-sm" title="Log Out">
            <i class="fa-solid fa-arrow-right-from-bracket"></i> Logout
          </button>
        </div>
      `;
    } else {
      // User is logged out
      authNavContainer.innerHTML = `
        <button onclick="openModal('auth-modal')" class="btn btn-secondary btn-sm">
          <i class="fa-solid fa-lock"></i> Sign In
        </button>
        <button onclick="openRegisterTab()" class="btn btn-primary btn-sm">
          <i class="fa-solid fa-user-plus"></i> Register
        </button>
      `;
    }
  }

  // Bind Login Form
  const loginForm = document.getElementById('login-form');
  if (loginForm) {
    loginForm.addEventListener('submit', handleLoginSubmit);
  }

  // Bind Register Form
  const registerForm = document.getElementById('register-form');
  if (registerForm) {
    registerForm.addEventListener('submit', handleRegisterSubmit);
  }
}

// Handle Login
async function handleLoginSubmit(e) {
  e.preventDefault();
  const email = document.getElementById('login-email').value.trim();
  const password = document.getElementById('login-password').value;
  const errorAlert = document.getElementById('login-error');

  if (errorAlert) errorAlert.style.display = 'none';

  const res = await apiFetch('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email, password })
  });

  if (res.success) {
    setToken(res.token);
    setUser(res.user);
    showToast(res.message, 'success');
    closeModal('auth-modal');

    // Route according to role
    if (res.user.role === 'citizen') {
      window.location.href = '/citizen';
    } else {
      window.location.href = '/admin';
    }
  } else {
    if (errorAlert) {
      errorAlert.innerText = res.message || 'Login failed.';
      errorAlert.style.display = 'block';
    } else {
      showToast(res.message || 'Login failed.', 'error');
    }
  }
}

// Handle Citizen Registration
async function handleRegisterSubmit(e) {
  e.preventDefault();
  const name = document.getElementById('reg-name').value.trim();
  const email = document.getElementById('reg-email').value.trim();
  const password = document.getElementById('reg-password').value;
  const phone = document.getElementById('reg-phone').value.trim();
  const ward = document.getElementById('reg-ward').value;
  const address = document.getElementById('reg-address').value.trim();
  const errorAlert = document.getElementById('reg-error');

  if (errorAlert) errorAlert.style.display = 'none';

  const res = await apiFetch('/api/auth/register', {
    method: 'POST',
    body: JSON.stringify({ name, email, password, phone, ward, address })
  });

  if (res.success) {
    setToken(res.token);
    setUser(res.user);
    showToast('Registration successful! Redirecting to Citizen Portal...', 'success');
    closeModal('auth-modal');
    setTimeout(() => {
      window.location.href = '/citizen';
    }, 800);
  } else {
    if (errorAlert) {
      errorAlert.innerText = res.message || 'Registration failed.';
      errorAlert.style.display = 'block';
    } else {
      showToast(res.message || 'Registration failed.', 'error');
    }
  }
}

// Quick Demo Login Shortcut
function quickLogin(role) {
  if (role === 'citizen') {
    document.getElementById('login-email').value = 'citizen@smartcity.gov';
    document.getElementById('login-password').value = 'citizen123';
  } else if (role === 'officer') {
    document.getElementById('login-email').value = 'officer@smartcity.gov';
    document.getElementById('login-password').value = 'officer123';
  } else if (role === 'admin') {
    document.getElementById('login-email').value = 'admin@smartcity.gov';
    document.getElementById('login-password').value = 'admin123';
  }

  // Trigger submit
  const loginForm = document.getElementById('login-form');
  if (loginForm) {
    loginForm.dispatchEvent(new Event('submit'));
  }
}

// Logout
function handleLogout() {
  removeToken();
  showToast('Logged out safely.', 'info');
  window.location.href = '/';
}

// Switch between Login and Register tabs in Modal
function switchAuthTab(tab) {
  const loginTab = document.getElementById('tab-login');
  const registerTab = document.getElementById('tab-register');
  const btnLoginTab = document.getElementById('btn-tab-login');
  const btnRegTab = document.getElementById('btn-tab-register');

  if (tab === 'login') {
    loginTab.style.display = 'block';
    registerTab.style.display = 'none';
    btnLoginTab.classList.add('btn-primary');
    btnLoginTab.classList.remove('btn-secondary');
    btnRegTab.classList.add('btn-secondary');
    btnRegTab.classList.remove('btn-primary');
  } else {
    loginTab.style.display = 'none';
    registerTab.style.display = 'block';
    btnRegTab.classList.add('btn-primary');
    btnRegTab.classList.remove('btn-secondary');
    btnLoginTab.classList.add('btn-secondary');
    btnLoginTab.classList.remove('btn-primary');
  }
}

function openRegisterTab() {
  openModal('auth-modal');
  switchAuthTab('register');
}
