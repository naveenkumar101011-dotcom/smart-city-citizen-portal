// =====================================================================
// Smart City Portal - Citizen Dashboard Logic
// =====================================================================

let currentActiveComplaint = null;

document.addEventListener('DOMContentLoaded', () => {
  // Check if logged in as citizen
  const user = getUser();
  if (!user) {
    window.location.href = '/';
    return;
  }

  setupCitizenUI(user);
  loadDashboardStats();
  loadComplaints();
  loadBills();
  loadPermits();
  loadMobility();
  loadPolls();
  bindCitizenForms();
});

// Setup Profile info in Sidebar
function setupCitizenUI(user) {
  const nameEl = document.getElementById('citizen-profile-name');
  const roleEl = document.getElementById('citizen-profile-role');
  const wardEl = document.getElementById('citizen-profile-ward');
  const avatarEl = document.getElementById('citizen-avatar');

  if (nameEl) nameEl.innerText = user.name;
  if (roleEl) roleEl.innerText = `${user.role.toUpperCase()} (ID: ${user.national_id || 'CTZN-001'})`;
  if (wardEl) wardEl.innerText = user.ward || 'Central Zone';
  if (avatarEl) avatarEl.innerText = user.name.charAt(0).toUpperCase();

  // Populate profile form inputs
  if (document.getElementById('prof-name')) document.getElementById('prof-name').value = user.name || '';
  if (document.getElementById('prof-email')) document.getElementById('prof-email').value = user.email || '';
  if (document.getElementById('prof-phone')) document.getElementById('prof-phone').value = user.phone || '';
  if (document.getElementById('prof-ward')) document.getElementById('prof-ward').value = user.ward || 'Ward 1 - Central Zone';
  if (document.getElementById('prof-address')) document.getElementById('prof-address').value = user.address || '';
}

// Navigation Tab Switcher
function showSection(sectionId, element) {
  document.querySelectorAll('.content-section').forEach(sec => sec.classList.remove('active'));
  document.querySelectorAll('.sidebar-link').forEach(link => link.classList.remove('active'));

  const target = document.getElementById(sectionId);
  if (target) {
    target.classList.add('active');
  }

  if (element) {
    element.classList.add('active');
  }
}

// =====================================================================
// 1. DASHBOARD OVERVIEW & STATS
// =====================================================================
async function loadDashboardStats() {
  const [complaintsRes, billsRes] = await Promise.all([
    apiFetch('/api/complaints'),
    apiFetch('/api/bills')
  ]);

  if (complaintsRes.success) {
    const list = complaintsRes.complaints;
    const total = list.length;
    const resolved = list.filter(c => c.status === 'resolved').length;
    const pending = list.filter(c => c.status !== 'resolved' && c.status !== 'rejected').length;

    if (document.getElementById('stat-total-complaints')) document.getElementById('stat-total-complaints').innerText = total;
    if (document.getElementById('stat-pending-complaints')) document.getElementById('stat-pending-complaints').innerText = pending;
    if (document.getElementById('stat-resolved-complaints')) document.getElementById('stat-resolved-complaints').innerText = resolved;

    renderRecentComplaintsWidget(list.slice(0, 3));
  }

  if (billsRes.success) {
    const unpaid = billsRes.bills.filter(b => b.status === 'unpaid');
    const unpaidAmount = unpaid.reduce((sum, b) => sum + b.amount, 0);

    if (document.getElementById('stat-pending-bills')) {
      document.getElementById('stat-pending-bills').innerText = `${unpaid.length} (${formatCurrency(unpaidAmount)})`;
    }
  }
}

function renderRecentComplaintsWidget(complaints) {
  const container = document.getElementById('recent-complaints-widget');
  if (!container) return;

  if (complaints.length === 0) {
    container.innerHTML = `<p style="color: var(--text-muted); font-style: italic;">No grievances filed yet.</p>`;
    return;
  }

  container.innerHTML = complaints.map(c => `
    <div style="background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius-md); padding: 1rem; margin-bottom: 0.75rem; display: flex; justify-content: space-between; align-items: center; gap: 1rem;">
      <div>
        <div style="font-weight: 700; color: var(--text-main); font-size: 0.95rem;">${c.title}</div>
        <div style="font-size: 0.82rem; color: var(--text-muted); margin-top: 0.2rem;">
          <span style="font-family: monospace; font-weight: 600;">${c.ticket_no}</span> • ${c.category} • ${formatDate(c.created_at)}
        </div>
      </div>
      <div style="display: flex; align-items: center; gap: 0.75rem;">
        <span class="badge-status status-${c.status}">${c.status.replace('_', ' ')}</span>
        <button class="btn btn-outline btn-sm" onclick="trackComplaint(${c.id})">
          <i class="fa-solid fa-eye"></i> Track
        </button>
      </div>
    </div>
  `).join('');
}

// =====================================================================
// 2. GRIEVANCE MANAGEMENT (CITY 311)
// =====================================================================
async function loadComplaints() {
  const statusFilter = document.getElementById('filter-complaint-status')?.value || 'all';
  const categoryFilter = document.getElementById('filter-complaint-category')?.value || 'all';

  const res = await apiFetch(`/api/complaints?status=${statusFilter}&category=${categoryFilter}`);
  const tbody = document.getElementById('complaints-table-body');
  if (!tbody) return;

  if (!res.success || res.complaints.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; color: var(--text-muted); padding: 2rem;">No grievances found.</td></tr>`;
    return;
  }

  tbody.innerHTML = res.complaints.map(c => `
    <tr>
      <td style="font-family: monospace; font-weight: 700; color: var(--primary);">${c.ticket_no}</td>
      <td style="font-weight: 600;">${c.title}</td>
      <td>${c.category}</td>
      <td>${c.ward}</td>
      <td><span class="priority-${c.priority}">${c.priority.toUpperCase()}</span></td>
      <td><span class="badge-status status-${c.status}">${c.status.replace('_', ' ')}</span></td>
      <td>
        <button class="btn btn-primary btn-sm" onclick="trackComplaint(${c.id})">
          <i class="fa-solid fa-location-crosshairs"></i> Track Status
        </button>
      </td>
    </tr>
  `).join('');
}

// View Complaint & 5-Step Progress Timeline
async function trackComplaint(complaintId) {
  const res = await apiFetch(`/api/complaints/${complaintId}`);
  if (!res.success) {
    showToast(res.message, 'error');
    return;
  }

  currentActiveComplaint = res.complaint;
  const c = res.complaint;
  const timeline = res.timeline;

  document.getElementById('track-ticket-no').innerText = c.ticket_no;
  document.getElementById('track-title').innerText = c.title;
  document.getElementById('track-category').innerText = c.category;
  document.getElementById('track-ward').innerText = c.ward;
  document.getElementById('track-landmark').innerText = c.landmark || 'N/A';
  document.getElementById('track-department').innerText = c.department || 'Awaiting Department Assignment';
  document.getElementById('track-description').innerText = c.description;

  // Status Badge
  const statusBadge = document.getElementById('track-status-badge');
  statusBadge.className = `badge-status status-${c.status}`;
  statusBadge.innerText = c.status.replace('_', ' ').toUpperCase();

  // Handle Photo Evidence
  const photoContainer = document.getElementById('track-photo-container');
  if (c.image_url) {
    photoContainer.innerHTML = `
      <p style="font-size: 0.85rem; font-weight: 700; margin-bottom: 0.4rem;">Photo Evidence:</p>
      <img src="${c.image_url}" alt="Grievance Evidence" style="max-height: 180px; border-radius: var(--radius-md); border: 1px solid var(--border); object-fit: cover;">
    `;
    photoContainer.style.display = 'block';
  } else {
    photoContainer.style.display = 'none';
  }

  // 5-Step Visual Timeline calculation
  // Stages: 1. Submitted, 2. Under Review, 3. In Progress, 4. Resolved
  const stages = ['submitted', 'under_review', 'in_progress', 'resolved'];
  const currentIndex = stages.indexOf(c.status);

  document.querySelectorAll('.timeline-step').forEach((stepEl, idx) => {
    stepEl.classList.remove('completed', 'active');
    if (c.status === 'rejected') {
      // Special rejected state
    } else if (idx < currentIndex) {
      stepEl.classList.add('completed');
    } else if (idx === currentIndex) {
      stepEl.classList.add('active');
    }
  });

  // Render Activity Log Entries
  const logsContainer = document.getElementById('track-logs-list');
  logsContainer.innerHTML = timeline.map(log => `
    <div style="border-left: 2px solid var(--primary); padding-left: 1rem; margin-bottom: 1rem; position: relative;">
      <div style="font-weight: 700; font-size: 0.9rem; color: var(--text-main);">${log.action}</div>
      <div style="font-size: 0.85rem; color: var(--text-muted); margin: 0.2rem 0;">${log.notes || ''}</div>
      <div style="font-size: 0.75rem; color: var(--text-muted); font-weight: 500;">
        <i class="fa-regular fa-clock"></i> ${formatDate(log.created_at)} • Logged by: <strong>${log.performed_by}</strong>
      </div>
    </div>
  `).join('');

  // Rating & Feedback Block (Visible if Resolved)
  const ratingSection = document.getElementById('track-rating-section');
  if (c.status === 'resolved') {
    ratingSection.style.display = 'block';
    if (c.rating) {
      ratingSection.innerHTML = `
        <div style="background: var(--success-light); border: 1px solid var(--success); border-radius: var(--radius-md); padding: 1rem; margin-top: 1rem;">
          <div style="font-weight: 700; color: #065f46;"><i class="fa-solid fa-star" style="color: #f59e0b;"></i> Your Rating: ${c.rating} / 5 Stars</div>
          <p style="font-size: 0.88rem; color: #065f46; margin-top: 0.3rem;">"${c.feedback || 'No comments provided'}"</p>
        </div>
      `;
    } else {
      ratingSection.innerHTML = `
        <div style="background: var(--warning-light); border: 1px solid var(--warning); border-radius: var(--radius-md); padding: 1rem; margin-top: 1rem;">
          <h4 style="font-size: 0.95rem; font-weight: 700; color: #92400e; margin-bottom: 0.5rem;">Citizen Satisfaction Rating</h4>
          <p style="font-size: 0.85rem; color: #92400e; margin-bottom: 0.75rem;">This grievance has been resolved! Please rate the promptness and quality of municipal action.</p>
          <div style="display: flex; gap: 0.5rem; margin-bottom: 0.75rem;">
            ${[1, 2, 3, 4, 5].map(star => `
              <button type="button" class="btn btn-secondary btn-sm" onclick="submitRating(${c.id}, ${star})">
                ${star} <i class="fa-solid fa-star" style="color: #f59e0b;"></i>
              </button>
            `).join('')}
          </div>
        </div>
      `;
    }
  } else {
    ratingSection.style.display = 'none';
  }

  openModal('complaint-track-modal');
}

// Submit Citizen Rating
async function submitRating(complaintId, stars) {
  const comment = prompt('Optional: Leave a brief feedback comment for the Municipal Department:') || '';
  const res = await apiFetch(`/api/complaints/${complaintId}/feedback`, {
    method: 'POST',
    body: JSON.stringify({ rating: stars, feedback: comment })
  });

  if (res.success) {
    showToast(res.message, 'success');
    trackComplaint(complaintId);
    loadComplaints();
  } else {
    showToast(res.message, 'error');
  }
}

// Auto-populate geolocation
function getDeviceLocation() {
  if ('geolocation' in navigator) {
    showToast('Acquiring precise GPS coordinates...', 'info');
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        document.getElementById('cmp-lat').value = pos.coords.latitude.toFixed(6);
        document.getElementById('cmp-lng').value = pos.coords.longitude.toFixed(6);
        showToast('Location coordinates tagged successfully!', 'success');
      },
      () => {
        // Fallback default coordinates
        document.getElementById('cmp-lat').value = '12.971600';
        document.getElementById('cmp-lng').value = '77.594600';
        showToast('Location services unavailable. Used Ward Central reference.', 'info');
      }
    );
  }
}

// =====================================================================
// 3. UTILITY BILLS & INSTANT PAYMENTS
// =====================================================================
async function loadBills() {
  const res = await apiFetch('/api/bills');
  const container = document.getElementById('bills-cards-container');
  const historyTbody = document.getElementById('bills-history-table-body');
  if (!container) return;

  if (!res.success || res.bills.length === 0) {
    container.innerHTML = `<p style="color: var(--text-muted);">No utility bills registered under your citizen profile.</p>`;
    return;
  }

  const unpaidBills = res.bills.filter(b => b.status === 'unpaid');
  const paidBills = res.bills.filter(b => b.status === 'paid');

  // Unpaid bill cards
  if (unpaidBills.length === 0) {
    container.innerHTML = `
      <div style="background: var(--success-light); border: 1px solid var(--success); border-radius: var(--radius-lg); padding: 1.5rem; text-align: center; grid-column: 1 / -1;">
        <i class="fa-solid fa-circle-check" style="font-size: 2rem; color: var(--success); margin-bottom: 0.5rem;"></i>
        <h3 style="color: #065f46; font-weight: 700;">All Utility Bills Clear!</h3>
        <p style="color: #065f46; font-size: 0.9rem;">You have zero outstanding municipal dues. Thank you for being a responsible citizen!</p>
      </div>
    `;
  } else {
    container.innerHTML = unpaidBills.map(b => `
      <div class="card">
        <div class="card-header">
          <span style="font-weight: 700; color: var(--text-main); font-size: 1.05rem;">
            <i class="fa-solid ${getUtilityIcon(b.utility_type)}" style="color: var(--primary); margin-right: 0.4rem;"></i>
            ${b.utility_type}
          </span>
          <span class="badge-status status-submitted">Unpaid</span>
        </div>
        <div style="margin: 1rem 0;">
          <div style="font-size: 1.85rem; font-weight: 800; color: var(--text-main);">${formatCurrency(b.amount)}</div>
          <div style="font-size: 0.85rem; color: var(--text-muted); margin-top: 0.2rem;">
            Billing Cycle: <strong>${b.billing_period}</strong>
          </div>
          <div style="font-size: 0.85rem; color: #b45309; margin-top: 0.2rem; font-weight: 600;">
            <i class="fa-regular fa-calendar-xmark"></i> Due Date: ${b.due_date}
          </div>
          <div style="font-size: 0.78rem; font-family: monospace; color: var(--text-muted); margin-top: 0.4rem;">
            Bill #: ${b.bill_no}
          </div>
        </div>
        <button class="btn btn-primary" style="width: 100%;" onclick="openPaymentModal(${b.id}, '${b.utility_type}', ${b.amount}, '${b.bill_no}')">
          <i class="fa-solid fa-credit-card"></i> Pay Now (${formatCurrency(b.amount)})
        </button>
      </div>
    `).join('');
  }

  // Payment History Table
  if (historyTbody) {
    if (paidBills.length === 0) {
      historyTbody.innerHTML = `<tr><td colspan="6" style="text-align:center; color: var(--text-muted);">No payment history found.</td></tr>`;
    } else {
      historyTbody.innerHTML = paidBills.map(b => `
        <tr>
          <td style="font-family: monospace; font-weight: 600;">${b.bill_no}</td>
          <td>${b.utility_type}</td>
          <td style="font-weight: 700;">${formatCurrency(b.amount)}</td>
          <td>${formatDate(b.payment_date)}</td>
          <td><span style="font-family: monospace; font-size: 0.85rem;">${b.transaction_ref}</span></td>
          <td>
            <button class="btn btn-secondary btn-sm" onclick="viewReceipt(${JSON.stringify(b).replace(/"/g, '&quot;')})">
              <i class="fa-solid fa-file-invoice"></i> Receipt
            </button>
          </td>
        </tr>
      `).join('');
    }
  }
}

function getUtilityIcon(type) {
  if (type.includes('Electricity')) return 'fa-bolt';
  if (type.includes('Water')) return 'fa-faucet-drip';
  if (type.includes('Property')) return 'fa-building-columns';
  if (type.includes('Sanitation')) return 'fa-trash-can';
  return 'fa-receipt';
}

function openPaymentModal(billId, utilityType, amount, billNo) {
  document.getElementById('pay-bill-id').value = billId;
  document.getElementById('pay-bill-type').innerText = utilityType;
  document.getElementById('pay-bill-amount').innerText = formatCurrency(amount);
  document.getElementById('pay-bill-no').innerText = billNo;
  openModal('payment-modal');
}

async function executePayment() {
  const billId = document.getElementById('pay-bill-id').value;
  const method = document.getElementById('payment-method-select').value;

  showToast('Connecting to Smart City Payment Gateway...', 'info');

  const res = await apiFetch(`/api/bills/pay/${billId}`, {
    method: 'POST',
    body: JSON.stringify({ payment_method: method })
  });

  if (res.success) {
    closeModal('payment-modal');
    showToast(res.message, 'success');
    loadBills();
    loadDashboardStats();

    // Display Printable Receipt
    viewReceipt(res.receipt);
  } else {
    showToast(res.message, 'error');
  }
}

function viewReceipt(receiptData) {
  const user = getUser();
  const printEl = document.getElementById('receipt-content-area');
  if (!printEl) return;

  printEl.innerHTML = `
    <div style="border: 2px dashed #0f172a; padding: 2rem; border-radius: var(--radius-md); background: #ffffff; color: #000000; font-family: 'Plus Jakarta Sans', sans-serif;">
      <div style="text-align: center; border-bottom: 2px solid #000; padding-bottom: 1rem; margin-bottom: 1.5rem;">
        <h2 style="font-size: 1.4rem; font-weight: 800; text-transform: uppercase;">Smart City Municipal Corporation</h2>
        <p style="font-size: 0.85rem; color: #555;">Official E-Governance Municipal Payment Receipt</p>
      </div>
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; font-size: 0.9rem; margin-bottom: 1.5rem;">
        <div><strong>Receipt / Txn Ref:</strong> ${receiptData.transaction_ref}</div>
        <div><strong>Date & Time:</strong> ${formatDate(receiptData.payment_date || new Date())}</div>
        <div><strong>Citizen Name:</strong> ${user.name}</div>
        <div><strong>National ID / Aadhaar:</strong> ${user.national_id || 'CTZN-984210'}</div>
        <div><strong>Bill Reference:</strong> ${receiptData.bill_no}</div>
        <div><strong>Payment Channel:</strong> ${receiptData.payment_method || 'Online Portal'}</div>
      </div>
      <div style="background: #f1f5f9; padding: 1rem; border-radius: 8px; margin-bottom: 1.5rem;">
        <div style="display: flex; justify-content: space-between; font-weight: 700; font-size: 1.1rem;">
          <span>${receiptData.utility_type} Fee</span>
          <span>${formatCurrency(receiptData.amount)}</span>
        </div>
      </div>
      <div style="text-align: center; font-size: 0.8rem; color: #666; border-top: 1px solid #ddd; padding-top: 1rem;">
        <p>This is a computer-generated tax receipt and requires no physical signature.</p>
        <p>Civic Centre, Smart City Governance Portal • 24x7 Citizen Support 1916</p>
      </div>
    </div>
  `;

  openModal('receipt-modal');
}

// =====================================================================
// 4. PERMITS & CERTIFICATES
// =====================================================================
async function loadPermits() {
  const res = await apiFetch('/api/permits');
  const tbody = document.getElementById('permits-table-body');
  if (!tbody) return;

  if (!res.success || res.permits.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6" style="text-align: center; color: var(--text-muted); padding: 2rem;">No applications filed.</td></tr>`;
    return;
  }

  tbody.innerHTML = res.permits.map(p => `
    <tr>
      <td style="font-family: monospace; font-weight: 700;">${p.application_no}</td>
      <td style="font-weight: 600;">${p.permit_type}</td>
      <td>${p.applicant_name}</td>
      <td>${formatDate(p.created_at)}</td>
      <td><span class="badge-status status-${p.status}">${p.status.toUpperCase()}</span></td>
      <td>
        ${p.status === 'approved' ? `
          <button class="btn btn-success btn-sm" onclick="viewDigitalCertificate('${p.certificate_no}', '${p.permit_type}', '${p.applicant_name}')">
            <i class="fa-solid fa-award"></i> View Certificate
          </button>
        ` : `
          <span style="font-size: 0.85rem; color: var(--text-muted);">${p.remarks || 'Under verification'}</span>
        `}
      </td>
    </tr>
  `).join('');
}

function viewDigitalCertificate(certNo, type, name) {
  const modalContent = document.getElementById('certificate-render-area');
  if (!modalContent) return;

  modalContent.innerHTML = `
    <div style="border: 4px double #1d4ed8; padding: 2.5rem; text-align: center; background: #ffffff; color: #0f172a; border-radius: var(--radius-lg); position: relative;">
      <div style="font-size: 0.85rem; text-transform: uppercase; letter-spacing: 0.1em; color: #1d4ed8; font-weight: 800;">
        Municipal Corporation of Smart City
      </div>
      <h2 style="font-size: 1.8rem; font-weight: 800; margin: 0.75rem 0;">DIGITAL CERTIFICATE</h2>
      <p style="font-size: 0.95rem; color: #64748b; margin-bottom: 1.5rem;">Issued under the Authority of the City Commissioner</p>

      <div style="margin: 2rem 0; font-size: 1.05rem; line-height: 1.8;">
        This is to officially certify that <strong>${name}</strong> has been granted approval for:
        <div style="font-size: 1.35rem; font-weight: 800; color: #1d4ed8; margin: 0.5rem 0;">${type}</div>
        Verification Certificate ID: <strong style="font-family: monospace;">${certNo}</strong>
      </div>

      <div style="display: flex; justify-content: space-between; align-items: flex-end; margin-top: 3rem; padding-top: 1.5rem; border-top: 1px solid #e2e8f0;">
        <div style="text-align: left; font-size: 0.8rem; color: #64748b;">
          <div>Digitally Verified by: Municipal Registrar</div>
          <div>Issued via: Smart City Citizen Portal</div>
        </div>
        <div style="text-align: center;">
          <div style="font-family: cursive; font-size: 1.2rem; color: #1d4ed8;">Rajesh Sharma</div>
          <div style="font-size: 0.75rem; font-weight: 700; text-transform: uppercase; color: #64748b;">Municipal Commissioner</div>
        </div>
      </div>
    </div>
  `;

  openModal('certificate-modal');
}

// =====================================================================
// 5. SMART MOBILITY & CIVIC POLLS
// =====================================================================
async function loadMobility() {
  const [parkingRes, transitRes] = await Promise.all([
    apiFetch('/api/mobility/parking'),
    apiFetch('/api/mobility/transit')
  ]);

  const parkingContainer = document.getElementById('parking-lots-container');
  if (parkingContainer && parkingRes.success) {
    parkingContainer.innerHTML = parkingRes.parking.map(p => {
      const pct = Math.round((p.available_spots / p.total_spots) * 100);
      const color = pct > 30 ? 'var(--success)' : (pct > 10 ? 'var(--warning)' : 'var(--danger)');

      return `
        <div class="card">
          <div class="card-header">
            <span style="font-weight: 700; color: var(--text-main);">${p.name}</span>
            <span style="font-size: 0.8rem; color: var(--text-muted);">${p.zone}</span>
          </div>
          <div style="margin: 1rem 0;">
            <div style="display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 0.5rem;">
              <span style="font-size: 1.75rem; font-weight: 800; color: ${color};">${p.available_spots}</span>
              <span style="font-size: 0.85rem; color: var(--text-muted);">/ ${p.total_spots} Spots Free</span>
            </div>
            <div style="background: var(--border); height: 8px; border-radius: 999px; overflow: hidden;">
              <div style="background: ${color}; width: ${pct}%; height: 100%;"></div>
            </div>
            <div style="font-size: 0.85rem; color: var(--text-muted); margin-top: 0.75rem;">
              <i class="fa-solid fa-indian-rupee-sign"></i> Rate: ₹${p.hourly_rate} / hour
            </div>
          </div>
        </div>
      `;
    }).join('');
  }

  const transitContainer = document.getElementById('transit-routes-container');
  if (transitContainer && transitRes.success) {
    transitContainer.innerHTML = transitRes.routes.map(r => `
      <div style="background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius-md); padding: 1rem; margin-bottom: 0.75rem; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 0.5rem;">
        <div>
          <span style="background: var(--primary-light); color: var(--primary); font-weight: 700; font-size: 0.8rem; padding: 0.2rem 0.5rem; border-radius: 4px; font-family: monospace;">
            ${r.id}
          </span>
          <strong style="margin-left: 0.5rem; font-size: 0.95rem;">${r.name}</strong>
          <div style="font-size: 0.82rem; color: var(--text-muted); margin-top: 0.2rem;">
            ${r.route} (${r.type})
          </div>
        </div>
        <div style="text-align: right;">
          <div style="font-size: 1rem; font-weight: 800; color: var(--success);"><i class="fa-solid fa-bus"></i> ${r.nextDeparture}</div>
          <div style="font-size: 0.75rem; color: var(--text-muted);">${r.status} • ${r.frequency}</div>
        </div>
      </div>
    `).join('');
  }
}

async function loadPolls() {
  const res = await apiFetch('/api/polls');
  const container = document.getElementById('polls-container');
  if (!container) return;

  if (!res.success || res.polls.length === 0) {
    container.innerHTML = `<p style="color: var(--text-muted);">No active citizen polls at this time.</p>`;
    return;
  }

  container.innerHTML = res.polls.map(poll => {
    return `
      <div class="card" style="margin-bottom: 1.5rem;">
        <div class="card-header">
          <h3 style="font-size: 1.15rem; font-weight: 800; color: var(--text-main);">${poll.title}</h3>
          <span class="badge-status status-under_review">${poll.category}</span>
        </div>
        <p style="font-size: 0.9rem; color: var(--text-muted); margin-bottom: 1.25rem;">${poll.description}</p>
        
        <div style="display: flex; flex-direction: column; gap: 0.85rem;">
          ${poll.options.map(opt => {
            const pct = poll.totalVotes > 0 ? Math.round((opt.vote_count / poll.totalVotes) * 100) : 0;
            const isUserVoted = poll.userVotedOption === opt.id;

            return `
              <div style="border: 1.5px solid ${isUserVoted ? 'var(--primary)' : 'var(--border)'}; border-radius: var(--radius-md); padding: 0.85rem 1rem; position: relative; overflow: hidden; background: var(--surface);">
                <div style="position: absolute; left: 0; top: 0; bottom: 0; width: ${pct}%; background: var(--primary-light); opacity: 0.4; z-index: 1;"></div>
                <div style="position: relative; z-index: 2; display: flex; justify-content: space-between; align-items: center;">
                  <span style="font-weight: 600; font-size: 0.92rem;">
                    ${isUserVoted ? '<i class="fa-solid fa-circle-check" style="color: var(--primary);"></i> ' : ''}${opt.option_text}
                  </span>
                  <div style="display: flex; align-items: center; gap: 0.75rem;">
                    <span style="font-weight: 700; font-size: 0.85rem; color: var(--text-muted);">${pct}% (${opt.vote_count} votes)</span>
                    ${!poll.hasVoted ? `
                      <button class="btn btn-outline btn-sm" onclick="voteInPoll(${poll.id}, ${opt.id})">Vote</button>
                    ` : ''}
                  </div>
                </div>
              </div>
            `;
          }).join('')}
        </div>
      </div>
    `;
  }).join('');
}

async function voteInPoll(pollId, optionId) {
  const res = await apiFetch(`/api/polls/${pollId}/vote`, {
    method: 'POST',
    body: JSON.stringify({ option_id: optionId })
  });

  if (res.success) {
    showToast(res.message, 'success');
    loadPolls();
  } else {
    showToast(res.message, 'error');
  }
}

// =====================================================================
// 6. FORM BINDINGS
// =====================================================================
function bindCitizenForms() {
  // File Grievance Form
  const grievanceForm = document.getElementById('new-grievance-form');
  if (grievanceForm) {
    grievanceForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const formData = new FormData(grievanceForm);

      showToast('Submitting grievance to Municipal Redressal Engine...', 'info');

      const res = await apiFetch('/api/complaints', {
        method: 'POST',
        body: formData
      });

      if (res.success) {
        showToast(res.message, 'success');
        grievanceForm.reset();
        closeModal('new-grievance-modal');
        loadComplaints();
        loadDashboardStats();
      } else {
        showToast(res.message, 'error');
      }
    });
  }

  // Apply Permit Form
  const permitForm = document.getElementById('new-permit-form');
  if (permitForm) {
    permitForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const permit_type = document.getElementById('permit-type-select').value;
      const applicant_name = document.getElementById('permit-applicant-name').value;
      const details = {
        notes: document.getElementById('permit-notes').value,
        idRef: document.getElementById('permit-id-ref').value
      };

      const res = await apiFetch('/api/permits', {
        method: 'POST',
        body: JSON.stringify({ permit_type, applicant_name, details })
      });

      if (res.success) {
        showToast(res.message, 'success');
        permitForm.reset();
        closeModal('new-permit-modal');
        loadPermits();
      } else {
        showToast(res.message, 'error');
      }
    });
  }

  // Profile Update Form
  const profileForm = document.getElementById('profile-settings-form');
  if (profileForm) {
    profileForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const name = document.getElementById('prof-name').value;
      const phone = document.getElementById('prof-phone').value;
      const ward = document.getElementById('prof-ward').value;
      const address = document.getElementById('prof-address').value;

      const res = await apiFetch('/api/auth/profile', {
        method: 'PUT',
        body: JSON.stringify({ name, phone, ward, address })
      });

      if (res.success) {
        setUser(res.user);
        setupCitizenUI(res.user);
        showToast(res.message, 'success');
      } else {
        showToast(res.message, 'error');
      }
    });
  }
}
