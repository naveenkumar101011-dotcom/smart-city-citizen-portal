// =====================================================================
// Smart City Portal - Municipal Admin & Department Officer Logic
// =====================================================================

let categoryChartInstance = null;
let wardChartInstance = null;
let currentAdminComplaintId = null;

document.addEventListener('DOMContentLoaded', () => {
  const user = getUser();
  if (!user || (user.role !== 'admin' && user.role !== 'officer')) {
    showToast('Unauthorized access. Administrative privileges required.', 'error');
    window.location.href = '/';
    return;
  }

  setupAdminUI(user);
  loadAdminStats();
  loadAllComplaints();
  loadAdminPermits();
  loadAdminAnnouncements();
  if (user.role === 'admin') {
    loadCitizensDirectory();
  } else {
    // Hide citizens directory tab if officer
    const userNav = document.getElementById('nav-citizens-tab');
    if (userNav) userNav.style.display = 'none';
  }
  bindAdminForms();
});

function setupAdminUI(user) {
  const nameEl = document.getElementById('admin-profile-name');
  const roleEl = document.getElementById('admin-profile-role');
  const deptEl = document.getElementById('admin-profile-dept');
  const avatarEl = document.getElementById('admin-avatar');

  if (nameEl) nameEl.innerText = user.name;
  if (roleEl) roleEl.innerText = user.role.toUpperCase();
  if (deptEl) deptEl.innerText = user.department || 'Municipal Administration';
  if (avatarEl) avatarEl.innerText = user.name.charAt(0).toUpperCase();
}

function showAdminSection(sectionId, element) {
  document.querySelectorAll('.content-section').forEach(sec => sec.classList.remove('active'));
  document.querySelectorAll('.sidebar-link').forEach(link => link.classList.remove('active'));

  const target = document.getElementById(sectionId);
  if (target) target.classList.add('active');
  if (element) element.classList.add('active');
}

// =====================================================================
// 1. ANALYTICS & DASHBOARD METRICS
// =====================================================================
async function loadAdminStats() {
  const res = await apiFetch('/api/admin/stats');
  if (!res.success) return;

  const s = res.stats;
  if (document.getElementById('adm-total-complaints')) document.getElementById('adm-total-complaints').innerText = s.totalComplaints;
  if (document.getElementById('adm-pending-complaints')) document.getElementById('adm-pending-complaints').innerText = s.pendingComplaints;
  if (document.getElementById('adm-in-progress-complaints')) document.getElementById('adm-in-progress-complaints').innerText = s.inProgressComplaints;
  if (document.getElementById('adm-resolved-complaints')) document.getElementById('adm-resolved-complaints').innerText = s.resolvedComplaints;
  if (document.getElementById('adm-resolution-rate')) document.getElementById('adm-resolution-rate').innerText = `${s.resolutionRate}%`;
  if (document.getElementById('adm-revenue-collected')) document.getElementById('adm-revenue-collected').innerText = formatCurrency(s.revenueCollected);
  if (document.getElementById('adm-citizens-count')) document.getElementById('adm-citizens-count').innerText = s.totalCitizens;

  // Render Charts if Chart.js is loaded
  renderAnalyticsCharts(s.categoryBreakdown, s.wardBreakdown);

  // Render Recent Activity Logs
  const activityList = document.getElementById('adm-recent-activity');
  if (activityList && s.recentActivity) {
    activityList.innerHTML = s.recentActivity.map(act => `
      <div style="border-left: 2px solid var(--primary); padding-left: 1rem; margin-bottom: 0.85rem; font-size: 0.88rem;">
        <div style="font-weight: 700; color: var(--text-main);">${act.action}</div>
        <div style="color: var(--text-muted); font-size: 0.82rem;">${act.ticket_no} - ${act.notes || ''}</div>
        <div style="font-size: 0.72rem; color: var(--text-muted); margin-top: 0.15rem;">
          ${formatDate(act.created_at)} • By <strong>${act.performed_by}</strong>
        </div>
      </div>
    `).join('');
  }
}

function renderAnalyticsCharts(categories, wards) {
  if (typeof Chart === 'undefined') return;

  // Category Doughnut Chart
  const ctxCat = document.getElementById('chart-complaint-categories');
  if (ctxCat) {
    if (categoryChartInstance) categoryChartInstance.destroy();
    categoryChartInstance = new Chart(ctxCat, {
      type: 'doughnut',
      data: {
        labels: categories.map(c => c.category),
        datasets: [{
          data: categories.map(c => c.count),
          backgroundColor: ['#2563eb', '#0ea5e9', '#10b981', '#f59e0b', '#8b5cf6', '#ef4444', '#64748b'],
          borderWidth: 2
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { position: 'bottom', labels: { boxWidth: 12, font: { size: 11 } } }
        }
      }
    });
  }

  // Ward Bar Chart
  const ctxWard = document.getElementById('chart-complaint-wards');
  if (ctxWard) {
    if (wardChartInstance) wardChartInstance.destroy();
    wardChartInstance = new Chart(ctxWard, {
      type: 'bar',
      data: {
        labels: wards.map(w => w.ward),
        datasets: [{
          label: 'Complaints',
          data: wards.map(w => w.count),
          backgroundColor: '#3b82f6',
          borderRadius: 6
        }]
      },
      options: {
        responsive: true,
        plugins: { legend: { display: false } },
        scales: {
          y: { beginAtZero: true, ticks: { precision: 0 } },
          x: { ticks: { font: { size: 10 } } }
        }
      }
    });
  }
}

// =====================================================================
// 2. GRIEVANCE MANAGEMENT & DISPATCH
// =====================================================================
async function loadAllComplaints() {
  const status = document.getElementById('adm-filter-status')?.value || 'all';
  const category = document.getElementById('adm-filter-category')?.value || 'all';
  const ward = document.getElementById('adm-filter-ward')?.value || 'all';
  const search = document.getElementById('adm-search-input')?.value || '';

  const res = await apiFetch(`/api/complaints?status=${status}&category=${category}&ward=${ward}&search=${encodeURIComponent(search)}`);
  const tbody = document.getElementById('adm-complaints-tbody');
  if (!tbody) return;

  if (!res.success || res.complaints.length === 0) {
    tbody.innerHTML = `<tr><td colspan="8" style="text-align: center; color: var(--text-muted); padding: 2rem;">No matching grievances found.</td></tr>`;
    return;
  }

  tbody.innerHTML = res.complaints.map(c => `
    <tr>
      <td style="font-family: monospace; font-weight: 700; color: var(--primary);">${c.ticket_no}</td>
      <td style="font-weight: 600;">${c.title}</td>
      <td>${c.category}</td>
      <td>${c.ward}</td>
      <td><strong>${c.citizen_name}</strong><br><small style="color:var(--text-muted);">${c.citizen_phone || ''}</small></td>
      <td><span class="priority-${c.priority}">${c.priority.toUpperCase()}</span></td>
      <td><span class="badge-status status-${c.status}">${c.status.replace('_', ' ')}</span></td>
      <td>
        <button class="btn btn-primary btn-sm" onclick="openDispatchModal(${c.id})">
          <i class="fa-solid fa-pen-to-square"></i> Action
        </button>
      </td>
    </tr>
  `).join('');
}

async function openDispatchModal(complaintId) {
  currentAdminComplaintId = complaintId;
  const res = await apiFetch(`/api/complaints/${complaintId}`);
  if (!res.success) return;

  const c = res.complaint;
  document.getElementById('disp-ticket-no').innerText = c.ticket_no;
  document.getElementById('disp-title').innerText = c.title;
  document.getElementById('disp-citizen').innerText = `${c.citizen_name} (${c.citizen_phone || 'No phone'})`;
  document.getElementById('disp-category').innerText = c.category;
  document.getElementById('disp-ward').innerText = c.ward;
  document.getElementById('disp-landmark').innerText = c.landmark || 'N/A';
  document.getElementById('disp-desc').innerText = c.description;

  document.getElementById('disp-status-select').value = c.status;
  document.getElementById('disp-dept-select').value = c.department || '';
  document.getElementById('disp-officer-input').value = c.assigned_to || '';
  document.getElementById('disp-notes').value = c.resolution_notes || '';

  // Evidence photo
  const photoEl = document.getElementById('disp-photo-container');
  if (c.image_url) {
    photoEl.innerHTML = `<img src="${c.image_url}" style="max-height: 160px; border-radius: 8px; border: 1px solid var(--border); object-fit: cover;">`;
    photoEl.style.display = 'block';
  } else {
    photoEl.style.display = 'none';
  }

  openModal('dispatch-modal');
}

async function saveComplaintStatus() {
  if (!currentAdminComplaintId) return;

  const status = document.getElementById('disp-status-select').value;
  const department = document.getElementById('disp-dept-select').value;
  const assigned_to = document.getElementById('disp-officer-input').value;
  const resolution_notes = document.getElementById('disp-notes').value;

  const res = await apiFetch(`/api/complaints/${currentAdminComplaintId}/status`, {
    method: 'PUT',
    body: JSON.stringify({ status, department, assigned_to, resolution_notes })
  });

  if (res.success) {
    showToast(res.message, 'success');
    closeModal('dispatch-modal');
    loadAllComplaints();
    loadAdminStats();
  } else {
    showToast(res.message, 'error');
  }
}

// =====================================================================
// 3. PERMITS & CERTIFICATES APPROVAL
// =====================================================================
async function loadAdminPermits() {
  const res = await apiFetch('/api/permits');
  const tbody = document.getElementById('adm-permits-tbody');
  if (!tbody) return;

  if (!res.success || res.permits.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; color: var(--text-muted); padding: 2rem;">No pending permits.</td></tr>`;
    return;
  }

  tbody.innerHTML = res.permits.map(p => `
    <tr>
      <td style="font-family: monospace; font-weight: 700;">${p.application_no}</td>
      <td style="font-weight: 600;">${p.permit_type}</td>
      <td>${p.applicant_name}</td>
      <td>${formatDate(p.created_at)}</td>
      <td><span class="badge-status status-${p.status}">${p.status.toUpperCase()}</span></td>
      <td><span style="font-family: monospace; font-size: 0.85rem;">${p.certificate_no || 'Pending'}</span></td>
      <td>
        <div style="display: flex; gap: 0.4rem;">
          <button class="btn btn-success btn-sm" onclick="updatePermitStatus(${p.id}, 'approved')" title="Approve">
            <i class="fa-solid fa-check"></i> Approve
          </button>
          <button class="btn btn-danger btn-sm" onclick="updatePermitStatus(${p.id}, 'rejected')" title="Reject">
            <i class="fa-solid fa-xmark"></i> Reject
          </button>
        </div>
      </td>
    </tr>
  `).join('');
}

async function updatePermitStatus(permitId, status) {
  const remarks = prompt(`Enter remarks for ${status.toUpperCase()}:`) || '';

  const res = await apiFetch(`/api/permits/${permitId}/status`, {
    method: 'PUT',
    body: JSON.stringify({ status, remarks })
  });

  if (res.success) {
    showToast(res.message, 'success');
    loadAdminPermits();
  } else {
    showToast(res.message, 'error');
  }
}

// =====================================================================
// 4. ANNOUNCEMENTS & CITY BROADCASTS
// =====================================================================
async function loadAdminAnnouncements() {
  const res = await apiFetch('/api/announcements');
  const listEl = document.getElementById('adm-announcements-list');
  if (!listEl) return;

  if (!res.success || res.announcements.length === 0) {
    listEl.innerHTML = `<p style="color: var(--text-muted);">No active broadcasts.</p>`;
    return;
  }

  listEl.innerHTML = res.announcements.map(a => `
    <div style="background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius-md); padding: 1.25rem; margin-bottom: 1rem;">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
        <h4 style="font-size: 1.05rem; font-weight: 700; color: var(--text-main);">${a.title}</h4>
        <span class="badge-status ${a.severity === 'critical' ? 'status-rejected' : (a.severity === 'warning' ? 'status-under_review' : 'status-submitted')}">
          ${a.severity.toUpperCase()}
        </span>
      </div>
      <p style="font-size: 0.9rem; color: var(--text-muted); margin-bottom: 0.5rem;">${a.content}</p>
      <div style="font-size: 0.78rem; color: var(--text-muted);">
        <i class="fa-regular fa-clock"></i> Broadcasted: ${formatDate(a.created_at)} • Source: <strong>${a.created_by}</strong>
      </div>
    </div>
  `).join('');
}

// =====================================================================
// 5. REGISTERED CITIZENS DIRECTORY
// =====================================================================
async function loadCitizensDirectory() {
  const res = await apiFetch('/api/admin/users');
  const tbody = document.getElementById('adm-citizens-tbody');
  if (!tbody) return;

  if (!res.success || res.users.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6" style="text-align: center; color: var(--text-muted);">No users found.</td></tr>`;
    return;
  }

  tbody.innerHTML = res.users.map(u => `
    <tr>
      <td style="font-weight: 700;">${u.name}</td>
      <td>${u.email}</td>
      <td>${u.phone || 'N/A'}</td>
      <td><span class="user-role-badge badge-${u.role}">${u.role}</span></td>
      <td>${u.ward || 'General'}</td>
      <td>${formatDate(u.created_at)}</td>
    </tr>
  `).join('');
}

// =====================================================================
// 6. FORM BINDINGS
// =====================================================================
function bindAdminForms() {
  // Broadcast Announcement Form
  const broadcastForm = document.getElementById('new-broadcast-form');
  if (broadcastForm) {
    broadcastForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const title = document.getElementById('bc-title').value;
      const category = document.getElementById('bc-category').value;
      const severity = document.getElementById('bc-severity').value;
      const content = document.getElementById('bc-content').value;

      const res = await apiFetch('/api/announcements', {
        method: 'POST',
        body: JSON.stringify({ title, category, severity, content })
      });

      if (res.success) {
        showToast(res.message, 'success');
        broadcastForm.reset();
        closeModal('new-broadcast-modal');
        loadAdminAnnouncements();
      } else {
        showToast(res.message, 'error');
      }
    });
  }
}
